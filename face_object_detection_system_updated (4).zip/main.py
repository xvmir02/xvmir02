
import sys
import requests
import json
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QTextEdit, QFileDialog, QLabel
from PyQt5.QtGui import QFont, QPalette, QColor
from PyQt5.QtCore import Qt
import cv2
import numpy as np

class App(QWidget):
    def __init__(self):
        super().__init__()
        self.title = 'Face and Object Detection System'
        self.left = 100
        self.top = 100
        self.width = 400
        self.height = 300
        self.initUI()

    def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)
        
        self.setStyleSheet("background-color: #f0f0f0;")

        layout = QVBoxLayout()

        title_label = QLabel("Detection System")
        title_label.setFont(QFont("Arial", 16, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(title_label)

        self.face_btn = QPushButton('Run Face Detection on Video', self)
        self.face_btn.setFont(QFont("Arial", 12))
        self.face_btn.setStyleSheet("background-color: #4CAF50; color: white; padding: 10px; border: none; border-radius: 5px;")
        self.face_btn.clicked.connect(self.run_face_detection)
        layout.addWidget(self.face_btn)

        self.object_btn = QPushButton('Run Object Detection on Video', self)
        self.object_btn.setFont(QFont("Arial", 12))
        self.object_btn.setStyleSheet("background-color: #2196F3; color: white; padding: 10px; border: none; border-radius: 5px;")
        self.object_btn.clicked.connect(self.run_object_detection)
        layout.addWidget(self.object_btn)

        self.result_box = QTextEdit(self)
        self.result_box.setFont(QFont("Arial", 10))
        self.result_box.setStyleSheet("padding: 10px; border: 1px solid #ccc; border-radius: 5px;")
        layout.addWidget(self.result_box)

        self.setLayout(layout)
        self.show()

    def run_face_detection(self):
        self.detect_video(face_detection=True)

    def run_object_detection(self):
        self.detect_video(face_detection=False)

    def detect_video(self, face_detection=True):
        options = QFileDialog.Options()
        video_file, _ = QFileDialog.getOpenFileName(self, "Select Video File", "", "Video Files (*.mp4;*.avi;*.mov)", options=options)
        if not video_file:
            return

        cap = cv2.VideoCapture(video_file)

        if face_detection:
            url = "https://aip.baidubce.com/oauth/2.0/token?client_id=Y1hils1nsruVgMLvVBzIa1QT&client_secret=GZSE615yrRN9ngBaQjeJu3UIGGfk4yQs&grant_type=client_credentials"
            token = self.get_access_token(url)
            model = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        else:
            url = "https://aip.baidubce.com/oauth/2.0/token?client_id=dd1agSBuYQuyJoBafUEszWyb&client_secret=pG2z0wrqd5DxslaJElY2dZQBQM6NhSWM&grant_type=client_credentials"
            token = self.get_access_token(url)
            net = cv2.dnn.readNet('ssd_mobilenet_v3_large_coco_2020_01_14.pbtxt', 'frozen_inference_graph.pb')
            model = net

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            if face_detection:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                faces = model.detectMultiScale(gray, 1.3, 5)
                for (x, y, w, h) in faces:
                    cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)
            else:
                blob = cv2.dnn.blobFromImage(frame, 0.007843, (300, 300), 127.5)
                model.setInput(blob)
                detections = model.forward()
                for i in range(detections.shape[2]):
                    confidence = detections[0, 0, i, 2]
                    if confidence > 0.2:
                        class_id = int(detections[0, 0, i, 1])
                        box = detections[0, 0, i, 3:7] * np.array([frame.shape[1], frame.shape[0], frame.shape[1], frame.shape[0]])
                        (startX, startY, endX, endY) = box.astype("int")
                        label = "{}: {:.2f}%".format(class_id, confidence * 100)
                        cv2.rectangle(frame, (startX, startY), (endX, endY), (255, 0, 0), 2)
                        y = startY - 15 if startY - 15 > 15 else startY + 15
                        cv2.putText(frame, label, (startX, y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 2)

            cv2.imshow('Video Detection', frame)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()

    def get_access_token(self, url):
        payload = json.dumps("")
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        
        response = requests.request("POST", url, headers=headers, data=payload)
        data = response.json()
        return data.get('access_token', 'No access token found')

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = App()
    sys.exit(app.exec_())
