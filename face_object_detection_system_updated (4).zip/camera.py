import cv2


class VideoCamera:
    def __init__(self, source=0):
        # 如果是0，则使用默认摄像头，否则尝试从文件读取
        if isinstance(source, int):
            self.cap = cv2.VideoCapture(source)
        else:
            self.cap = cv2.VideoCapture(source)

    def read(self):
        return self.cap.read()

    def release(self):
        self.cap.release()