
# Face and Object Detection System

This project combines face detection and object detection using OpenCV.

## Files

- `camera.py`: Contains camera handling code.
- `face_detection.py`: Contains face detection logic.
- `main.py`: Main entry point for the system.
- `object_detection.py`: Contains object detection logic.

## How to Run

1. Install the required packages:
    ```
    pip install -r requirements.txt
    ```

2. Run the main script:
    ```
    python main.py
    ```

Press 'q' to quit the video stream.
